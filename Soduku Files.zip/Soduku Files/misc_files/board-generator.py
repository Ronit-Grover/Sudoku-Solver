# Python board generator

import random

class BoardGenerator(object):
    def __init__(self, size):
        self.size = size
    
    def checkLegal():


    def create():
        grid = []
        for i in range(0,self.size):
            i = []
            for j in range(0,self.size):
                grid.append(i)